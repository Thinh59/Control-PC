﻿#include "function.h"
#include <thread> 

void handleClientRequest(SOCKET clientSocket)
{
    char buffer[BUFFER_SIZE];
    int bytesReceived;

    while (true)
    {
        bytesReceived = recv(clientSocket, buffer, BUFFER_SIZE, 0);
        if (bytesReceived <= 0)
        {
            cout << "Client disconnected or error occurred." << endl;
            break;
        }

        buffer[bytesReceived] = '\0';
        string command(buffer);

        if (command == "exit")
        {
            cout << "Client requested to terminate the connection." << endl;
            break;
        }
        else if (command.find("get file ") == 0)
        {
            string fileName = command.substr(9);
            sendFile(clientSocket, fileName.c_str());
        }
        else if (command == "list apps")
        {
            sendListApps(clientSocket);
        }
        else if (command.find("start app ") == 0)
        {
            string appName = command.substr(10);
            startApp(clientSocket, appName);
        }
        else if (command.find("stop app ") == 0)
        {
            string appName = command.substr(9);
            stopApp(clientSocket, appName);
        }
        else if (command == "list services")
        {
            sendListServices(clientSocket);
        }
        else if (command.find("start service ") == 0)
        {
            string serviceName = command.substr(14);
            startService(clientSocket, serviceName);
        }
        else if (command.find("stop service ") == 0)
        {
            string serviceName = command.substr(13);
            stopService(clientSocket, serviceName);
        }
        else if (command == "list process")
        {
            sendListProcess(clientSocket);
        }
        else if (command.find("start process ") == 0)
        {
            string processPath = command.substr(14);
            StartProcess(clientSocket, processPath);
        }
        else if (command.find("stop process ") == 0)
        {
            string processName = command.substr(13);
            StopProcess(clientSocket, processName);
        }
        else if (command == "screen shot")
        {
            sendCaptureScreen(clientSocket);
        }
        else if (command == "shut down")
        {
            shutdown();
        }
        else if (command == "restart")
        {
            restart();
        }
        else if (command == "log out")
        {
            logOut();
        }
        else if (command.find("start webcam") == 0)
        {
            startWebcam(command);
            sendFile(clientSocket, "Webcam.mp4");
            deleteFile("Webcam.mp4");
        }
        else if (command.find("delete file ") == 0)
        {
            handleDeleteFile(clientSocket, command);
        }
        else
        {
            cout << "Unknown command: " << command << endl;
            send(clientSocket, "Unknown command", 15, 0);
        }
    }

    closesocket(clientSocket); // Đóng socket client khi kết thúc xử lý
}

int main()
{
    WSADATA wsaData;
    SOCKET serverSocket;
    sockaddr_in serverAddr, clientAddr;
    int addrLen = sizeof(clientAddr);

    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        cerr << "WSAStartup failed." << endl;
        return -1;
    }

    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == INVALID_SOCKET) {
        cerr << "Socket creation error" << endl;
        WSACleanup();
        return -1;
    }

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(PORT);

    if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0)
    {
        cerr << "Bind failed" << endl;
        closesocket(serverSocket);
        WSACleanup();
        return -1;
    }

    if (listen(serverSocket, 3) < 0)
    {
        cerr << "Listen failed" << endl;
        closesocket(serverSocket);
        WSACleanup();
        return -1;
    }

    cout << "Server is running and waiting for connections..." << endl;

    while (true)
    {
        SOCKET clientSocket = accept(serverSocket, (struct sockaddr*)&clientAddr, &addrLen);
        if (clientSocket == INVALID_SOCKET)
        {
            cerr << "Accept failed, continuing to listen..." << endl;
            continue;
        }

        cout << "Client connected." << endl;

        
       thread clientThread(handleClientRequest, clientSocket);
       clientThread.detach(); 
    }

    closesocket(serverSocket);
    WSACleanup();
    return 0;
}
