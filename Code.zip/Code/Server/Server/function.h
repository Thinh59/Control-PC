#ifndef FUNCTION_H
#define FUNCTION_H

#include <iostream>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <vector>
#include <string>
#include <windows.h>
#include <tchar.h>
#include <mfapi.h>
#include <mfplay.h>
#include <mfobjects.h>
#include <mfidl.h>
#include <mfreadwrite.h>
#include <mfmediaengine.h>
#include <dshow.h>
#include <chrono>
#include <mferror.h>
#include <winuser.h>
#include <fstream>
#include <cstring>
#include <tlhelp32.h>
#include <algorithm>
#include <cstdlib>
#include <cstdio>
#include <sstream>
#include <iomanip>

#pragma comment(lib, "mf.lib")
#pragma comment(lib, "mfplat.lib")
#pragma comment(lib, "mfplay.lib")
#pragma comment(lib, "mfreadwrite.lib")
#pragma comment(lib, "mfuuid.lib")

#pragma comment(lib, "ws2_32.lib")

#define PORT 8080
#define BUFFER_SIZE 65536

using namespace std;

void sendFile(SOCKET clientSocket, const char* fileName);
wstring stringToWString(const string& str);
string runCommand(const char* command);
bool deleteFile(const string& fileName);
void handleGetFile(SOCKET clientSocket, const char* command);
void handleDeleteFile(SOCKET clientSocket, const string& command);
void sendListApps(SOCKET clientSock);
HANDLE startApp(SOCKET clientSock, const string& processPath);
void stopApp(SOCKET clientSock, const string& pidStr);
string ConvertWideCharToString(LPWSTR wideString);
void sendListServices(SOCKET clientSocket);
bool startService(SOCKET clientSocket, const string& serviceName);
bool stopService(SOCKET clientSocket, const string& serviceName);
void sendListProcess(SOCKET clientSock);
HANDLE StartProcess(SOCKET clientSock, const string& processPath);
void StopProcess(SOCKET clientSock, const string& processName);
void CaptureScreen(const wchar_t* filename);
void startWebcam(const string& command);
void startStopCamera();
void sendCaptureScreen(SOCKET clientSock);
void shutdown();
void restart();
void logOut();

#endif