﻿#include "function.h"

void sendFile(SOCKET clientSocket, const char* fileName) {
    ifstream file(fileName, ios::binary);
    if (!file.is_open()) {
        cerr << "Error: Cannot open file!" << endl;
        const char* errorMsg = "ERROR:CANNOT_OPEN_FILE";
        send(clientSocket, errorMsg, strlen(errorMsg), 0);
        return;
    }

    // Lấy kích thước file
    file.seekg(0, ios::end);
    long long fileSize = file.tellg();
    file.seekg(0, ios::beg);

    // Gửi kích thước file
    long long networkFileSize = htonll(fileSize);
    if (send(clientSocket, (char*)&networkFileSize, sizeof(networkFileSize), 0) == SOCKET_ERROR) {
        cerr << "Error: Failed to send file size!" << endl;
        file.close();
        return;
    }

    // Đợi xác nhận từ client
    char ack[32];
    if (recv(clientSocket, ack, sizeof(ack), 0) <= 0) {
        cerr << "Error: No size acknowledgment from client!" << endl;
        file.close();
        return;
    }

    // Gửi dữ liệu file với cơ chế xác nhận
    char buffer[BUFFER_SIZE];
    long long totalSent = 0;
    while (totalSent < fileSize) {
        // Đọc một phần file
        int toRead = min((long long)BUFFER_SIZE, fileSize - totalSent);
        file.read(buffer, toRead);
        int bytesRead = file.gcount();

        // Gửi chunk size trước
        int networkChunkSize = htonl(bytesRead);
        if (send(clientSocket, (char*)&networkChunkSize, sizeof(networkChunkSize), 0) == SOCKET_ERROR) {
            cerr << "Error: Failed to send chunk size!" << endl;
            file.close();
            return;
        }

        // Gửi dữ liệu
        int bytesSent = send(clientSocket, buffer, bytesRead, 0);
        if (bytesSent == SOCKET_ERROR) {
            cerr << "Error: Failed to send data!" << endl;
            file.close();
            return;
        }

        // Đợi xác nhận từ client
        if (recv(clientSocket, ack, sizeof(ack), 0) <= 0) {
            cerr << "Error: No chunk acknowledgment from client!" << endl;
            file.close();
            return;
        }

        totalSent += bytesSent;

        // In tiến độ
        float progress = (float)totalSent * 100 / fileSize;
        cout << "\rProgress: " << fixed << setprecision(2) << progress << "%" << flush;
    }

    // Gửi tín hiệu kết thúc file với xác nhận
    const char* fileEndSignal = "END_OF_FILE_TRANSFER";
    if (send(clientSocket, fileEndSignal, strlen(fileEndSignal), 0) == SOCKET_ERROR) {
        cerr << "\nError: Failed to send end signal!" << endl;
        file.close();
        return;
    }

    // Đợi xác nhận cuối cùng
    if (recv(clientSocket, ack, sizeof(ack), 0) <= 0) {
        cerr << "\nError: No final acknowledgment from client!" << endl;
        file.close();
        return;
    }

    file.close();
    cout << "\nFile sent successfully: " << fileName << endl;
}
wstring stringToWString(const string& str)
{
    int len;
    int slength = (int)str.length() + 1;
    len = MultiByteToWideChar(CP_UTF8, 0, str.c_str(), slength, 0, 0);
    wstring r(len, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, str.c_str(), slength, &r[0], len);
    return r;
}

string runCommand(const char* command)
{
    string result;
    char buffer[128];

    HANDLE hReadPipe, hWritePipe;
    SECURITY_ATTRIBUTES sa =
    {
        sizeof(SECURITY_ATTRIBUTES), NULL, TRUE
    };

    if (!CreatePipe(&hReadPipe, &hWritePipe, &sa, 0))
    {
        cerr << "CreatePipe failed." << endl;
        return result;
    }

    STARTUPINFO si = { sizeof(STARTUPINFO) };
    si.dwFlags |= STARTF_USESTDHANDLES;
    si.hStdOutput = hWritePipe;

    PROCESS_INFORMATION pi;
    wstring wideCommand = stringToWString(command);
    LPWSTR commandW = const_cast<LPWSTR>(wideCommand.c_str());

    if (CreateProcess(NULL, commandW, NULL, NULL, TRUE, 0, NULL, NULL, &si, &pi))
    {
        CloseHandle(hWritePipe);

        DWORD bytesRead;
        while (ReadFile(hReadPipe, buffer, sizeof(buffer) - 1, &bytesRead, NULL) && bytesRead > 0)
        {
            buffer[bytesRead] = '\0';
            result += buffer;
        }

        WaitForSingleObject(pi.hProcess, INFINITE);
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
    }
    else
    {
        cerr << "CreateProcess failed." << endl;
    }

    CloseHandle(hReadPipe);
    return result;
}

bool deleteFile(const string& fileName)
{
    if (remove(fileName.c_str()) == 0)
    {
        cout << "File deleted successfully." << endl;
        return true;
    }
    else
    {
        cerr << "Error deleting the file." << endl;
        return false;
    }
}

void handleGetFile(SOCKET clientSocket, const char* command)
{
    const char* fileName = command + strlen("get file ");
    sendFile(clientSocket, fileName);
}

void handleDeleteFile(SOCKET clientSocket, const string& command)
{
    string fileName = command.substr(strlen("delete file "));
    ofstream fout("response.txt");
    if (deleteFile(fileName))
    {
        string response = "File deleted successfully.\n";
        fout << response << endl;
        sendFile(clientSocket, "response.txt");
    }
    else
    {
        string response = "Failed to delete file.\n";
        fout << response << endl;
        sendFile(clientSocket, "response.txt");
    }
}

void sendListApps(SOCKET clientSock)
{
    string result = runCommand("powershell \"gps | where { $_.MainWindowTitle } | select Description, ID, @{Name='ThreadCount'; Expression={($_.Threads).Count}}\"");
    cout << "Result to send: " << result << endl;

    ofstream fresult("ListApps.txt");
    fresult << result;
    fresult.close();

    sendFile(clientSock, "ListApps.txt");
    deleteFile("ListApps.txt");
}
//Start app by Process Path
HANDLE startApp(SOCKET clientSock, const string& processPath)
{
    STARTUPINFOA si = { sizeof(STARTUPINFOA) };
    PROCESS_INFORMATION pi = { 0 };

    if (CreateProcessA(
        processPath.c_str(),    // Đường dẫn tới tiến trình
        NULL,                   // Dòng lệnh (không có tham số)
        NULL,                   // Security Attributes cho tiến trình
        NULL,                   // Security Attributes cho thread
        FALSE,                  // Thừa kế handle không
        0,                      // Flags
        NULL,                   // Biến môi trường
        NULL,                   // Thư mục làm việc
        &si,                    // Thông tin Startup
        &pi                     // Thông tin Process
    ))
    {
        Sleep(5000);
        CaptureScreen(L"startApp.bmp");
        cout << "Process started successfully with PID: " << pi.dwProcessId << endl;
        CloseHandle(pi.hThread);

        sendFile(clientSock, "startApp.bmp");
        deleteFile("startApp.bmp");
        return pi.hProcess;
    }
    else
    {
        ofstream fres("response.txt");
        fres << "Failed to start process. Error: " << GetLastError() << endl;
        cerr << "Failed to start process. Error: " << GetLastError() << endl;

        fres.close();
        sendFile(clientSock, "response.txt");
        deleteFile("response.txt");
        return NULL;
    }

}
//Stop App by PID
void stopApp(SOCKET clientSock, const string& pidStr)
{
    ofstream fout("response.txt");
    try
    {
        DWORD processId = stoul(pidStr);

        HANDLE hProcess = OpenProcess(PROCESS_TERMINATE, FALSE, processId);
        if (hProcess != NULL)
        {
            if (TerminateProcess(hProcess, 0))
            {
                fout << "Process with ID " << processId << " has been stopped." << endl;
                cout << "Process with ID " << processId << " has been stopped." << endl;
                CloseHandle(hProcess);
            }
            else
            {
                fout << "Failed to terminate process with ID " << processId << "." << endl;
                cout << "Failed to terminate process with ID " << processId << "." << endl;
            }
            CloseHandle(hProcess);
        }
        else
        {
            fout << "Failed to open process with ID " << processId << "." << endl;
            cout << "Failed to open process with ID " << processId << "." << endl;
        }
    }
    catch (const invalid_argument& e)
    {
        fout << "Invalid PID: " << pidStr << " is not a valid number." << endl;
        cout << "Invalid PID: " << pidStr << " is not a valid number." << endl;
    }
    catch (const out_of_range& e)
    {
        fout << "PID value " << pidStr << " is out of range." << endl;
        cout << "PID value " << pidStr << " is out of range." << endl;
    }
    fout.close();
    sendFile(clientSock, "response.txt");
    deleteFile("response.txt");
}

string ConvertWideCharToString(LPWSTR wideString) {
    if (!wideString) return "";
    int size = WideCharToMultiByte(CP_UTF8, 0, wideString, -1, NULL, 0, NULL, NULL);
    string result(size, '\0');
    WideCharToMultiByte(CP_UTF8, 0, wideString, -1, &result[0], size, NULL, NULL);
    return result;
}

void sendListServices(SOCKET clientSocket) {
    ofstream fout("ListServices.txt");

    SC_HANDLE hSCManager = OpenSCManager(NULL, NULL, SC_MANAGER_ENUMERATE_SERVICE);
    if (!hSCManager) {
        cerr << "Failed to open Service Control Manager. Error: " << GetLastError() << endl;
        return;
    }

    DWORD bytesNeeded, servicesReturned, resumeHandle = 0;
    LPBYTE buffer = nullptr;

    EnumServicesStatusEx(hSCManager, SC_ENUM_PROCESS_INFO, SERVICE_WIN32,
        SERVICE_STATE_ALL, nullptr, 0, &bytesNeeded,
        &servicesReturned, &resumeHandle, nullptr);

    buffer = new BYTE[bytesNeeded];
    if (EnumServicesStatusEx(hSCManager, SC_ENUM_PROCESS_INFO, SERVICE_WIN32,
        SERVICE_ACTIVE, buffer, bytesNeeded, &bytesNeeded,
        &servicesReturned, &resumeHandle, nullptr)) {
        LPENUM_SERVICE_STATUS_PROCESS services = (LPENUM_SERVICE_STATUS_PROCESS)buffer;

        for (DWORD i = 0; i < servicesReturned; ++i) {
            fout << "Service Name: " << ConvertWideCharToString(services[i].lpServiceName) << endl;
            fout << "Display Name: " << ConvertWideCharToString(services[i].lpDisplayName) << endl;
            fout << "Status: "
                << (services[i].ServiceStatusProcess.dwCurrentState == SERVICE_RUNNING ? "Running" : "Stopped")
                << endl << endl;
        }
    }
    else {
        cerr << "Failed to enumerate services. Error: " << GetLastError() << endl;
    }

    delete[] buffer;
    CloseHandle(hSCManager);
    fout.close();
    sendFile(clientSocket, "ListServices.txt");
    deleteFile("ListServices.txt");
}

bool startService(SOCKET clientSocket, const string& serviceName)
{
    ofstream fout("response.txt");
    wstring wserviceName = stringToWString(serviceName);

    SC_HANDLE scm = OpenSCManager(nullptr, nullptr, SC_MANAGER_CONNECT);
    if (scm == nullptr)
    {
        fout << "Failed to open service manager." << endl;
        wcerr << L"Failed to open service manager." << endl;
        sendFile(clientSocket, "response.txt");
        return false;
    }

    SC_HANDLE service = OpenService(scm, wserviceName.c_str(), SERVICE_QUERY_STATUS | SERVICE_START);
    if (service == nullptr)
    {
        fout << "Failed to open service." << endl;
        wcerr << L"Failed to open service: " << wserviceName << endl;
        CloseServiceHandle(scm);
        fout.close();
        sendFile(clientSocket, "response.txt");
        deleteFile("response.txt");
        return false;
    }

    // Kiểm tra trạng thái dịch vụ
    SERVICE_STATUS_PROCESS ssp;
    DWORD bytesNeeded;
    if (QueryServiceStatusEx(service, SC_STATUS_PROCESS_INFO, (LPBYTE)&ssp, sizeof(SERVICE_STATUS_PROCESS), &bytesNeeded))
    {
        if (ssp.dwCurrentState != SERVICE_STOPPED && ssp.dwCurrentState != SERVICE_STOP_PENDING)
        {
            fout << "Service is already running." << endl;
            wcerr << L"Service " << wserviceName << L" is already running." << endl;
            CloseServiceHandle(service);
            CloseServiceHandle(scm);
            fout.close();
            sendFile(clientSocket, "response.txt");
            deleteFile("response.txt");
            return false;
        }
    }

    if (!StartService(service, 0, nullptr))
    {
        fout << "Failed to start service." << endl;
        wcerr << L"Failed to start service: " << wserviceName << endl;
        CloseServiceHandle(service);
        CloseServiceHandle(scm);
        sendFile(clientSocket, "response.txt");
        return false;
    }

    fout << "Service started successfully." << endl;
    wcout << L"Service " << wserviceName << L" started successfully." << endl;

    CloseServiceHandle(service);
    CloseServiceHandle(scm);
    fout.close();
    sendFile(clientSocket, "response.txt");
    deleteFile("response.txt");
    return true;
}

bool stopService(SOCKET clientSocket, const string& serviceName)
{
    ofstream fout("response.txt");
    wstring wserviceName = stringToWString(serviceName);

    SC_HANDLE scm = OpenSCManager(nullptr, nullptr, SC_MANAGER_CONNECT);
    if (scm == nullptr)
    {
        fout << "Failed to open service manager." << endl;
        wcerr << L"Failed to open service manager." << endl;
        fout.close();
        sendFile(clientSocket, "response.txt");
        deleteFile("response.txt");
        return false;
    }

    SC_HANDLE service = OpenService(scm, wserviceName.c_str(), SERVICE_QUERY_STATUS | SERVICE_STOP);
    if (service == nullptr)
    {
        fout << "Failed to open service." << endl;
        wcerr << L"Failed to open service: " << wserviceName << endl;
        CloseServiceHandle(scm);
        fout.close();
        sendFile(clientSocket, "response.txt");
        deleteFile("response.txt");
        return false;
    }

    // Kiểm tra trạng thái dịch vụ
    SERVICE_STATUS_PROCESS ssp;
    DWORD bytesNeeded;
    if (QueryServiceStatusEx(service, SC_STATUS_PROCESS_INFO, (LPBYTE)&ssp, sizeof(SERVICE_STATUS_PROCESS), &bytesNeeded))
    {
        if (ssp.dwCurrentState == SERVICE_STOPPED || ssp.dwCurrentState == SERVICE_STOP_PENDING)
        {
            fout << "Service is already stopped." << endl;
            wcerr << L"Service " << wserviceName << L" is already stopped." << endl;
            CloseServiceHandle(service);
            CloseServiceHandle(scm);
            fout.close();
            sendFile(clientSocket, "response.txt");
            deleteFile("response.txt");
            return false;
        }
    }

    SERVICE_STATUS status;
    if (!ControlService(service, SERVICE_CONTROL_STOP, &status))
    {
        fout << "Failed to stop service." << endl;
        wcerr << L"Failed to stop service: " << wserviceName << endl;
        CloseServiceHandle(service);
        CloseServiceHandle(scm);
        fout.close();
        sendFile(clientSocket, "response.txt");
        deleteFile("response.txt");
        return false;
    }

    fout << "Service stopped successfully." << endl;
    wcout << L"Service " << wserviceName << L" stopped successfully." << endl;

    CloseServiceHandle(service);
    CloseServiceHandle(scm);
    fout.close();
    sendFile(clientSocket, "response.txt");
    deleteFile("response.txt");
    return true;
}

void sendListProcess(SOCKET clientSock)
{
    string result = runCommand("tasklist");
    cout << "Result to send: " << result << endl;
    ofstream fresult("ListProcess.txt");
    fresult << result;

    fresult.close();
    sendFile(clientSock, "ListProcess.txt");
    deleteFile("ListProcess.txt");
}

HANDLE StartProcess(SOCKET clientSock, const string& processPath)
{
    STARTUPINFOA si = { sizeof(STARTUPINFOA) };
    PROCESS_INFORMATION pi = { 0 };

    if (CreateProcessA(
        processPath.c_str(),    // Đường dẫn tới tiến trình
        NULL,                   // Dòng lệnh (không có tham số)
        NULL,                   // Security Attributes cho tiến trình
        NULL,                   // Security Attributes cho thread
        FALSE,                  // Thừa kế handle không
        0,                      // Flags
        NULL,                   // Biến môi trường
        NULL,                   // Thư mục làm việc
        &si,                    // Thông tin Startup
        &pi                     // Thông tin Process
    ))
    {
        cout << "Process started successfully with PID: " << pi.dwProcessId << endl;
        CloseHandle(pi.hThread);
        Sleep(5000);
        CaptureScreen(L"startService.bmp");
        sendFile(clientSock, "startService.bmp");
        deleteFile("startService.bmp");// Đóng handle thread vì không cần thiết
        return pi.hProcess;      // Trả về handle tiến trình để dừng sau này
    }
    else
    {
        ofstream fres("response.txt");
        fres << "Failed to start process. Error: " << GetLastError() << endl;
        cerr << "Failed to start process. Error: " << GetLastError() << endl;

        fres.close();
        sendFile(clientSock, "response.txt");
        deleteFile("response.txt");
        return NULL;
    }

}
//Stop process by Process Name
void StopProcess(SOCKET clientSock, const string& processName)
{
    // Tạo chuỗi lệnh taskkill
    string command = "taskkill /IM " + processName + " /F";

    // Thực thi lệnh trong hệ thống
    int result = system(command.c_str());
    ofstream fres("response.txt");
    // Kiểm tra kết quả
    if (result == 0)
    {
        fres << "Process " << processName << " stopped successfully." << endl;
        cout << "Process " << processName << " stopped successfully." << endl;
    }
    else
    {
        fres << "Failed to stop process " << processName << "." << endl;
        cerr << "Failed to stop process " << processName << "." << endl;
    }
    fres.close();
    sendFile(clientSock, "response.txt");
    deleteFile("response.txt");
}

void CaptureScreen(const wchar_t* filename)
{
    int screenX = GetSystemMetrics(SM_CXSCREEN);
    int screenY = GetSystemMetrics(SM_CYSCREEN);

    HDC hScreenDC = GetDC(NULL);
    HDC hMemoryDC = CreateCompatibleDC(hScreenDC);

    HBITMAP hBitmap = CreateCompatibleBitmap(hScreenDC, screenX, screenY);

    SelectObject(hMemoryDC, hBitmap);

    BitBlt(hMemoryDC, 0, 0, screenX, screenY, hScreenDC, 0, 0, SRCCOPY);

    BITMAPFILEHEADER   bmfHeader;
    BITMAPINFOHEADER   bi;

    bi.biSize = sizeof(BITMAPINFOHEADER);
    bi.biWidth = screenX;
    bi.biHeight = screenY;
    bi.biPlanes = 1;
    bi.biBitCount = 24;
    bi.biCompression = BI_RGB;
    bi.biSizeImage = 0;
    bi.biXPelsPerMeter = 0;
    bi.biYPelsPerMeter = 0;
    bi.biClrUsed = 0;
    bi.biClrImportant = 0;

    DWORD dwBmpSize = ((screenX * bi.biBitCount + 31) / 32) * 4 * screenY;

    HANDLE hDIB = GlobalAlloc(GHND, dwBmpSize);
    char* lpbitmap = (char*)GlobalLock(hDIB);

    GetDIBits(hMemoryDC, hBitmap, 0, (UINT)screenY, lpbitmap, (BITMAPINFO*)&bi, DIB_RGB_COLORS);

    HANDLE hFile = CreateFile(filename, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

    DWORD dwSizeofDIB = dwBmpSize + sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);
    bmfHeader.bfOffBits = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);
    bmfHeader.bfSize = dwSizeofDIB;
    bmfHeader.bfType = 0x4D42;

    DWORD dwBytesWritten = 0;
    WriteFile(hFile, (LPSTR)&bmfHeader, sizeof(BITMAPFILEHEADER), &dwBytesWritten, NULL);
    WriteFile(hFile, (LPSTR)&bi, sizeof(BITMAPINFOHEADER), &dwBytesWritten, NULL);
    WriteFile(hFile, (LPSTR)lpbitmap, dwBmpSize, &dwBytesWritten, NULL);

    CloseHandle(hFile);

    GlobalUnlock(hDIB);
    GlobalFree(hDIB);

    DeleteObject(hBitmap);
    DeleteDC(hMemoryDC);
    ReleaseDC(NULL, hScreenDC);
}

void sendCaptureScreen(SOCKET clientSock)
{
    CaptureScreen(L"screenshot.bmp");
    sendFile(clientSock, "screenshot.bmp");
    deleteFile("screenshot.bmp");
}

void recordVideo(const string& webcamName, const string& outputFile, int duration) {
    // Tạo câu lệnh ffmpeg với codec video khác và thay đổi định dạng đầu ra
    string command = "ffmpeg -t " + to_string(duration) +
        " -f dshow -i video=\"" + webcamName + "\" -vcodec mpeg4 -acodec pcm_s16le -q:v 5 -y " + outputFile;

    // Gọi lệnh hệ thống và đọc kết quả trả về
    FILE* fp = _popen(command.c_str(), "r");
    if (fp == nullptr) {
        cerr << "Error while executing FFmpeg command." << endl;
        return;
    }

    char buffer[256];
    while (fgets(buffer, sizeof(buffer), fp) != nullptr) {
        cout << buffer;  // Hiển thị thông tin quá trình ghi video
    }

    int result = _pclose(fp);
    if (result == 0) {
        cout << "Video recorded successfully: " << outputFile << endl;
    }
    else {
        cerr << "Error while recording video. Please check FFmpeg setup.\n";
    }
}

void startWebcam(const string& command) {
    if (command.find("start webcam") != string::npos) {
        // Tách tên webcam và thời gian quay video từ lệnh nhập vào
        size_t startPos = command.find("\"") + 1;  // Vị trí sau dấu nháy kép
        size_t endPos = command.find("\"", startPos);  // Vị trí dấu nháy kép kết thúc
        string webcamName = command.substr(startPos, endPos - startPos);

        // Tìm số giây quay video
        size_t timePos = command.find_last_of(" ");
        int duration = stoi(command.substr(timePos + 1));

        // Gọi hàm recordVideo với thông tin đã tách được
        recordVideo(webcamName, "Webcam.mp4", duration);

    }
}

void shutdown()
{
    HANDLE hToken;
    OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY | TOKEN_ADJUST_PRIVILEGES, &hToken);

    TOKEN_PRIVILEGES tp;
    LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, &tp.Privileges[0].Luid);
    tp.PrivilegeCount = 1;
    tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

    AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(tp), NULL, NULL);

    UINT uFlags = EWX_SHUTDOWN;

    ExitWindowsEx(uFlags, SHTDN_REASON_MAJOR_SOFTWARE | SHTDN_REASON_MINOR_OTHER | SHTDN_REASON_FLAG_PLANNED);
}

void restart()
{
    HANDLE hToken;
    OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY | TOKEN_ADJUST_PRIVILEGES, &hToken);

    TOKEN_PRIVILEGES tp;
    LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, &tp.Privileges[0].Luid);
    tp.PrivilegeCount = 1;
    tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

    AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(tp), NULL, NULL);

    UINT uFlags = EWX_REBOOT;

    ExitWindowsEx(uFlags, SHTDN_REASON_MAJOR_SOFTWARE | SHTDN_REASON_MINOR_OTHER | SHTDN_REASON_FLAG_PLANNED);
}

void logOut()
{
    HANDLE hToken;
    OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY | TOKEN_ADJUST_PRIVILEGES, &hToken);

    TOKEN_PRIVILEGES tp;
    LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, &tp.Privileges[0].Luid);
    tp.PrivilegeCount = 1;
    tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

    AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(tp), NULL, NULL);

    UINT uFlags = EWX_LOGOFF;

    ExitWindowsEx(uFlags, SHTDN_REASON_MAJOR_SOFTWARE | SHTDN_REASON_MINOR_OTHER | SHTDN_REASON_FLAG_PLANNED);
}