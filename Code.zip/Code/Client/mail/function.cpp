﻿#include "function.h"

string url_decode(const string& str)
{
	string decoded = "";
	for (size_t i = 0; i < str.length(); i++)
	{
		if (str[i] == '%' && i + 2 < str.length())
		{
			char hex[] = { str[i + 1], str[i + 2], 0 };
			decoded += (char)strtol(hex, nullptr, 16);
			i += 2;
		}
		else if (str[i] == '+')
		{
			decoded += ' ';
		}
		else {
			decoded += str[i];
		}
	}
	return decoded;
}

string extractAuthCode(const string& url)
{
	size_t pos = url.find("?");
	if (pos != string::npos)
	{
		string query = url.substr(pos + 1);

		map<string, string> params;
		istringstream queryStream(query);
		string keyValue;

		while (getline(queryStream, keyValue, '&'))
		{
			size_t delimiterPos = keyValue.find('=');
			if (delimiterPos != string::npos)
			{
				string key = keyValue.substr(0, delimiterPos);
				string value = keyValue.substr(delimiterPos + 1);
				params[key] = value;
			}
		}

		auto it = params.find("code");
		if (it != params.end())
		{
			return url_decode(it->second);
		}
	}
	return "";
}

string SocketListenOnPort(int port)
{
	WSADATA wsaData;
	int wsaerr;
	WORD wVersionRequested = MAKEWORD(2, 2);
	wsaerr = WSAStartup(wVersionRequested, &wsaData);
	if (wsaerr != 0)
	{
		cout << "The Winsock dll not found!" << endl;
		return 0;
	}

	SOCKET serverSOCKET = INVALID_SOCKET;
	serverSOCKET = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (serverSOCKET == INVALID_SOCKET)
	{
		cout << "Error at socket(): " << WSAGetLastError() << endl;
		WSACleanup();
		return 0;
	}

	sockaddr_in service;
	service.sin_family = AF_INET;
	InetPton(AF_INET, L"0.0.0.0", &service.sin_addr.s_addr);
	service.sin_port = htons(port);
	if (::bind(serverSOCKET, (SOCKADDR*)&service, sizeof(service)) == SOCKET_ERROR)
	{
		cout << "bind() failed: " << WSAGetLastError() << endl;
		closesocket(serverSOCKET);
		WSACleanup();
		return 0;
	}

	if (listen(serverSOCKET, 1) == SOCKET_ERROR)
	{
		cout << "listen() failed: " << WSAGetLastError() << endl;
		closesocket(serverSOCKET);
		WSACleanup();
		return 0;
	}

	SOCKET acceptSOCKET;
	acceptSOCKET = accept(serverSOCKET, NULL, NULL);
	if (acceptSOCKET == INVALID_SOCKET)
	{
		cout << "accept failed: " << WSAGetLastError() << endl;
		closesocket(serverSOCKET);
		WSACleanup();
		return 0;
	}

	char buffer[256];
	int bytesRead = 0;
	string output;

	bytesRead = recv(acceptSOCKET, buffer, 256, 0);
	output = buffer;
	output = extractAuthCode(output);

	WSACleanup();
	return output;
}

string UrlEncode(const string& str)
{
	ostringstream encoded;

	for (size_t i = 0; i < str.length(); ++i)
	{
		unsigned char c = str[i];

		// Check if the character is a valid unreserved character in a URL
		if ((c >= 'a' && c <= 'z') ||
			(c >= 'A' && c <= 'Z') ||
			(c >= '0' && c <= '9') ||
			(c == '-' || c == '_' || c == '.' || c == '~'))
		{
			encoded << c;
		}
		// Otherwise, percent-encode the character
		else
		{
			encoded << '%'
				<< uppercase << setw(2) << setfill('0')
				<< hex << (int)c;
		}
	}

	return encoded.str();
}

int openAuthorizationURL(const char* url)
{
	wchar_t wideUrl[256];
	size_t convertedChars = 0;
	mbstowcs_s(&convertedChars, wideUrl, 256, url, _TRUNCATE);

	HINSTANCE result = ShellExecute(0, L"open", wideUrl, 0, 0, SW_SHOWNORMAL);

	if ((int)result <= 32)
	{
		MessageBox(0, L"Failed to open URL", L"Error", MB_OK);
		return 1;
	}

	return 0;
}

string GetAuthCode(Credentials cred, string scope, string redirect_uri, int port)
{
	string authUrl = "https://accounts.google.com/o/oauth2/v2/auth?response_type=code&scope=" + UrlEncode(scope) + "&redirect_uri=" + UrlEncode(redirect_uri) + "&client_id=" + UrlEncode(cred.client_id);
	openAuthorizationURL(authUrl.c_str());
	string authCode = SocketListenOnPort(port);
	return authCode;
}

size_t WriteCallBack(void* contents, size_t size, size_t nmemb, string* output)
{
	size_t totalSize = size * nmemb;
	output->append((char*)contents, totalSize);
	return totalSize;
}

void ExtractAccessAndRefresh(string rawToken, string& accessToken, string& refreshToken)
{
	json info = json::parse(rawToken);
	accessToken = info["access_token"];
	refreshToken = info["refresh_token"];
}

string ExchangeRawAccessRefreshToken(Credentials cred, string scope, string redirect_uri, string authCode)
{
	string readBuffer;
	string postFields = "code=" + authCode + "&client_id=" + UrlEncode(cred.client_id) + "&client_secret=" + UrlEncode(cred.client_secret) + "&redirect_uri=" + UrlEncode(redirect_uri) + "&grant_type=authorization_code";
	CURL* curl = curl_easy_init();

	struct curl_slist* headers = NULL;
	headers = curl_slist_append(headers, "Content-Type: application/x-www-form-urlencoded");
	curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

	if (curl)
	{
		curl_easy_setopt(curl, CURLOPT_URL, "https://oauth2.googleapis.com/token");
		curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
		curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, postFields.length());
		curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postFields.c_str());
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallBack);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);

		curl_easy_perform(curl);
	}

	curl_easy_cleanup(curl);
	return readBuffer;
}

Tokens GetTokens(Credentials cred, string scope, string redirect_uri, int port)
{
	string authCode = GetAuthCode(cred, scope, redirect_uri, port);
	string rawTokens = ExchangeRawAccessRefreshToken(cred, scope, redirect_uri, authCode);
	string accessToken, refreshToken;
	ExtractAccessAndRefresh(rawTokens, accessToken, refreshToken);
	Tokens tokens =
	{
		accessToken, refreshToken
	};
	return tokens;
}

json GetMailList(Tokens tokens, int maxMsgs, string query)
{
	string readBuffer;
	CURL* curl = curl_easy_init();
	if (!curl)
		throw std::runtime_error("Failed to initialize CURL");
	struct curl_slist* headers = NULL;
	headers = curl_slist_append(headers, ("Authorization: Bearer " + tokens.access_token).c_str());
	curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
	string url = "https://gmail.googleapis.com/gmail/v1/users/me/messages";

	//Query parameters
	url += "?maxResults=" + to_string(maxMsgs);
	if (query != "NA")
	{
		url += "&q=" + query;
	}

	curl_easy_setopt(curl, CURLOPT_URL, url.c_str());

	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallBack);;
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);
	curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);

	CURLcode res = curl_easy_perform(curl);
	if (res != CURLE_OK)
	{
		std::cerr << "curl_easy_perform() failed: " << curl_easy_strerror(res) << std::endl;
	}

	curl_easy_cleanup(curl);

	return json::parse(readBuffer);
}

json GetMailFromID(Tokens tokens, string mailID)
{
	string readBuffer;
	CURL* curl = curl_easy_init();
	if (!curl)
		throw std::runtime_error("Failed to initialize CURL");
	struct curl_slist* headers = NULL;
	headers = curl_slist_append(headers, ("Authorization: Bearer " + tokens.access_token).c_str());
	curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
	string url = "https://gmail.googleapis.com/gmail/v1/users/me/messages/" + mailID;

	curl_easy_setopt(curl, CURLOPT_URL, url.c_str());

	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallBack);;
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, &readBuffer);
	curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);

	CURLcode res = curl_easy_perform(curl);
	if (res != CURLE_OK)
	{
		std::cerr << "curl_easy_perform() failed: " << curl_easy_strerror(res) << std::endl;
	}

	curl_easy_cleanup(curl);

	return json::parse(readBuffer);
}

void WriteFile(string path, string content)
{
	ofstream file(path);
	file << content;
	file.close();
}

Tokens ReadTokens(string path)
{
	ifstream file;
	file.open(path);
	string access_token, refresh_token;
	file >> access_token >> refresh_token;
	file.close();

	Tokens tokens;
	tokens.access_token = access_token;
	tokens.refresh_token = refresh_token;
	return tokens;
}

string GetMailSubject(Tokens tokens, string mailID)
{
	json m = GetMailFromID(tokens, mailID);

	int n = m["payload"]["headers"].size();
	int subject_index = 0;
	for (int i = 0; i < n; i++)
	{
		if (m["payload"]["headers"][i]["name"] == "Subject")
		{
			return m["payload"]["headers"][i]["value"];
		}
	}

	return "N/A";
}

string GetMailSnippet(Tokens tokens, string mailID)
{
	json m = GetMailFromID(tokens, mailID);
	return m["snippet"];
}

string GetMailReceivedTime(Tokens tokens, string mailID)
{
	json m = GetMailFromID(tokens, mailID);

	int n = m["payload"]["headers"].size();
	for (int i = 0; i < n; i++)
	{
		if (m["payload"]["headers"][i]["name"] == "Received")
		{
			return m["payload"]["headers"][i]["value"];
		}
	}

	return "N/A";
}

string ReadEmail(Tokens tokens)
{
	json ml = GetMailList(tokens, 1, "is:unread");
	return GetMailSubject(tokens, ml["messages"][0]["id"]);
}

string encode_base64(const vector<unsigned char>& buffer)
{
	const char base64_chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";  // Standard Base64 charset
	string encoded;
	int val = 0;
	int valb = -6;

	for (unsigned char c : buffer)
	{
		val = (val << 8) + c;
		valb += 8;
		while (valb >= 0)
		{
			encoded.push_back(base64_chars[(val >> valb) & 0x3F]);
			valb -= 6;
		}
	}

	if (valb > -6)
	{
		encoded.push_back(base64_chars[((val << 8) >> (valb + 8)) & 0x3F]);
	}

	while (encoded.size() % 4 != 0)
	{
		encoded.push_back('=');
	}

	return encoded;
}

vector<unsigned char> read_file(const string& filename)
{
	ifstream file(filename, ios::binary);
	if (!file)
	{
		throw runtime_error("Unable to open file: " + filename);
	}

	vector<unsigned char> buffer((std::istreambuf_iterator<char>(file)), istreambuf_iterator<char>());
	return buffer;
}

void ExtractFileInfo(string pathToFileContent, string& fileName, string& fileType)
{
	int dotIndex = 0;
	for (int i = pathToFileContent.length() - 1; i >= 0; i--)
	{
		if (pathToFileContent[i] == '.')
		{
			dotIndex = i;
			break;
		}
		fileType = pathToFileContent[i] + fileType;
	}

	for (int i = dotIndex - 1; i >= 0; i--)
	{
		if (pathToFileContent[i] != '/' && pathToFileContent[i] != '\\')
		{
			fileName = pathToFileContent[i] + fileName;
		}
		else break;
	}
}

string ByteFile(string path)
{
	vector<unsigned char> bytes = read_file(path);
	return encode_base64(bytes);;
}

string MIMEStructure(string from, string to, string subject, string pathToFileContent, string textContent)
{
	string fileName, fileType;
	ExtractFileInfo(pathToFileContent, fileName, fileType);
	string mime = "";
	mime += "To: " + to + "\r\n";
	mime += "From: " + from + "\r\n";
	mime += "Subject: " + subject + "\r\n";
	mime += "MIME-Version: 1.0\r\n";
	mime += "Content-Type: multipart/mixed; boundary=\"bd__foobar\"\r\n";
	mime += "\r\n";
	mime += "--bd__foobar\r\n";
	mime += "Content-Type: text/plain; charset=\"utf-8\"\r\n";
	mime += "Content-Transfer-Encoding: 7bit\r\n\r\n";
	mime += textContent + "\r\n\r\n";
	mime += "--bd__foobar\r\n";
	mime += "Content-Type: application/" + fileType + "; name=\"" + fileName + "." + fileType + "\"\r\n";
	mime += "Content-Disposition: attachment; filename=\"" + fileName + "." + fileType + "\"\r\n";
	mime += "Content-Transfer-Encoding: base64\r\n\r\n";
	mime += ByteFile(pathToFileContent);
	mime += "\r\n\r\n--bd__foobar--";
	return mime;
}

void SendEmail(Tokens tokens, string from, string to, string subject, string pathToFileContent, string textContent)
{
	CURL* curl = curl_easy_init();
	if (!curl)
		throw std::runtime_error("Failed to initialize CURL");
	struct curl_slist* headers = NULL;
	headers = curl_slist_append(headers, ("Authorization: Bearer " + tokens.access_token).c_str());
	headers = curl_slist_append(headers, "Accept: application/json");
	headers = curl_slist_append(headers, "Content-Type: message/rfc822");
	curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
	string url = "https://gmail.googleapis.com/upload/gmail/v1/users/me/messages/send";

	string msg = MIMEStructure(from, to, subject, pathToFileContent, textContent);
	curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, msg.c_str());
	curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);

	CURLcode res = curl_easy_perform(curl);
	if (res != CURLE_OK)
	{
		std::cerr << "curl_easy_perform() failed: " << curl_easy_strerror(res) << std::endl;
	}

	curl_easy_cleanup(curl);
}

string GetMailSenderName(Tokens tokens, string mailID) 
{
	json m = GetMailFromID(tokens, mailID);

	int n = m["payload"]["headers"].size();
	for (int i = 0; i < n; i++) 
	{
		if (m["payload"]["headers"][i]["name"] == "From") 
		{
			return m["payload"]["headers"][i]["value"];
		}
	}

	return "N/A"; // Trả về "N/A" nếu không tìm thấy thông tin người gửi
}

string FileName(const string& path)
{
	size_t lastSlash = path.find_last_of("\\");
	if (lastSlash == string::npos)
		return path;
	return path.substr(lastSlash + 1);
}

void receiveFile(SOCKET serverSocket, const char* fileName, HWND hEdit) {
	// Nhận kích thước file
	long long networkFileSize;
	if (recv(serverSocket, (char*)&networkFileSize, sizeof(networkFileSize), 0) <= 0) {
		SendMessageA(hEdit, EM_SETSEL, -1, -1);
		SendMessageA(hEdit, EM_REPLACESEL, 0, (LPARAM)"Error: Failed to receive file size!\r\n");
		return;
	}
	long long fileSize = ntohll(networkFileSize);

	// Gửi xác nhận đã nhận kích thước file
	const char* sizeAck = "SIZE_ACK";
	send(serverSocket, sizeAck, strlen(sizeAck), 0);

	// Mở file để ghi
	ofstream file(fileName, ios::binary);
	if (!file.is_open()) {
		SendMessageA(hEdit, EM_SETSEL, -1, -1);
		SendMessageA(hEdit, EM_REPLACESEL, 0, (LPARAM)"Error: Cannot open file to write!\r\n");
		return;
	}

	// Nhận dữ liệu file theo chunks
	char buffer[BUFFER_SIZE];
	long long totalBytesReceived = 0;

	while (totalBytesReceived < fileSize) {
		// Nhận kích thước chunk
		int networkChunkSize;
		if (recv(serverSocket, (char*)&networkChunkSize, sizeof(networkChunkSize), 0) <= 0) {
			SendMessageA(hEdit, EM_SETSEL, -1, -1);
			SendMessageA(hEdit, EM_REPLACESEL, 0, (LPARAM)"Error: Failed to receive chunk size!\r\n");
			file.close();
			return;
		}
		int chunkSize = ntohl(networkChunkSize);

		// Nhận dữ liệu chunk
		int bytesReceived = 0;
		while (bytesReceived < chunkSize) {
			int result = recv(serverSocket, buffer + bytesReceived, chunkSize - bytesReceived, 0);
			if (result <= 0) {
				SendMessageA(hEdit, EM_SETSEL, -1, -1);
				SendMessageA(hEdit, EM_REPLACESEL, 0, (LPARAM)"Error: Connection lost while receiving data!\r\n");
				file.close();
				return;
			}
			bytesReceived += result;
		}

		// Ghi dữ liệu vào file
		file.write(buffer, bytesReceived);
		totalBytesReceived += bytesReceived;

		// Gửi xác nhận đã nhận chunk
		const char* chunkAck = "CHUNK_ACK";
		send(serverSocket, chunkAck, strlen(chunkAck), 0);

		// Hiển thị tiến độ
		/*float progress = (float)totalBytesReceived * 100 / fileSize;
		string progressMsg = "\rProgress: " + to_string(progress) + "%\r\n";
		SendMessageA(hEdit, EM_SETSEL, -1, -1);
		SendMessageA(hEdit, EM_REPLACESEL, 0, (LPARAM)progressMsg.c_str());*/
	}

	// Nhận tín hiệu kết thúc file
	char endSignal[32];
	int endSignalSize = recv(serverSocket, endSignal, sizeof(endSignal), 0);
	if (endSignalSize <= 0) {
		SendMessageA(hEdit, EM_SETSEL, -1, -1);
		SendMessageA(hEdit, EM_REPLACESEL, 0, (LPARAM)"Error: Failed to receive end signal!\r\n");
		file.close();
		return;
	}
	endSignal[endSignalSize] = '\0';

	// Kiểm tra tín hiệu kết thúc
	if (strcmp(endSignal, "END_OF_FILE_TRANSFER") == 0) {
		// Gửi xác nhận cuối cùng
		const char* finalAck = "FINAL_ACK";
		send(serverSocket, finalAck, strlen(finalAck), 0);

		string message = "File received successfully as: " + string(fileName) + "\r\n";
		SendMessageA(hEdit, EM_SETSEL, -1, -1);
		SendMessageA(hEdit, EM_REPLACESEL, 0, (LPARAM)message.c_str());
	}

	file.close();
}
bool deleteFile(const string& fileName)
{
	if (remove(fileName.c_str()) == 0)
	{
		cout << "File deleted successfully." << endl;
		return true;
	}
	else
	{
		cerr << "Error deleting the file." << endl;
		return false;
	}
}

Tokens Login()
{
	Credentials cred;
	cred.client_id = "914001157903-n9dmqhiec8o57ko1893k9k1rmu576jd9.apps.googleusercontent.com";
	cred.client_secret = "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";
	string scope = "https://mail.google.com";
	int port = 55555;
	string redirect_uri = "http://localhost:" + to_string(port) + "/callback";

	Tokens tokens = GetTokens(cred, scope, redirect_uri, port);
	WriteFile("tokens.txt", tokens.access_token + "\n" + tokens.refresh_token);

	return tokens;
}

Tokens Start()
{
	Tokens tokens = ReadTokens("tokens.txt");
	return tokens;
}

bool CheckTokensExist(const string& filename) 
{
	ifstream file(filename);
	return file.good();
}