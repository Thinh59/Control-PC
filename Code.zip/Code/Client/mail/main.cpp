﻿#include "function.h"
#include "app.h"

extern HWND hwnd;
extern HWND hEdit;
extern SOCKET clientSocket;
string command = " ";
string mailID = " ";
string to = "";

bool stopReadingMail = 0;

bool Socket(const string IP)
{
	// Initialize Winsock
	WSADATA wsaData;
	if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
		MessageBox(NULL, L"WSAStartup failed", L"Error", MB_OK);
		return 0;
	}
	// Create socket
	clientSocket = socket(AF_INET, SOCK_STREAM, 0);
	if (clientSocket == INVALID_SOCKET) {
		MessageBox(NULL, L"Socket creation failed", L"Error", MB_OK);
		WSACleanup();
		return 0;
	}

	// Connect to server
	sockaddr_in serverAddr = {};
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(8080); // Replace with your server port
	inet_pton(AF_INET, IP.c_str(), &serverAddr.sin_addr); // Replace with your server IP

	if (connect(clientSocket, (sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
		MessageBox(NULL, L"Failed to connect to server", L"Error", MB_OK);
		closesocket(clientSocket);
		WSACleanup();
		return 0;
	}

	return 1;
}

bool Mail(Tokens tokens, string& IP)
{
	json ml = GetMailList(tokens, 1, "is:unread");
	if (mailID != ml["messages"][0]["id"])
	{
		command = ReadEmail(tokens);
		mailID = ml["messages"][0]["id"];
		to = GetMailSenderName(tokens, mailID);
	}
	else
	{
		command = "None";
		return 0;
	}
		
	// Kiểm tra cấu trúc của email
	size_t spacePos = command.find(' '); // Tìm khoảng trắng đầu tiên
	if (spacePos == string::npos) {
		// Không tìm thấy khoảng trắng => Email không hợp lệ
		return 0;
	}

	// Tách IP và command
	IP = command.substr(0, spacePos);
	command = command.substr(spacePos + 1);

	// Kiểm tra tính hợp lệ của IP
	sockaddr_in sa;
	if (inet_pton(AF_INET, IP.c_str(), &(sa.sin_addr)) <= 0) {
		// IP không hợp lệ => Bỏ qua email
		return 0;
	}

	return 1;
}

void sendCommand(SOCKET sock, Tokens tokens)
{
	string from = "";
	string subject;
	string path;
	string text;

	if (command != "None")
	{
		send(sock, command.c_str(), static_cast<int>(command.size()), 0);
		if (command == "exit")
		{
			SendMessage(hEdit, EM_REPLACESEL, 0, (LPARAM)L"Exiting...\r\n");

			Sleep(2000);

			PostMessage(hwnd, WM_CLOSE, 0, 0);

			closesocket(sock);
		}

		if (command.find("get file ") == 0)
		{
			string fileName = "received_" + FileName(command.substr(9));  // Phần tên file sau "get file "
			path = PATH + fileName;
			receiveFile(sock, path.c_str(), hEdit);
			text = "Sended.";
			subject = "GOT FILE " + fileName;
			SendEmail(tokens, from, to, subject, path, text);
			deleteFile(path);
			closesocket(sock);
		}
		else if (command == "list apps")
		{
			string fileName = "list_app.txt";
			path = PATH + fileName;
			receiveFile(sock, path.c_str(), hEdit);
			text = "Sended.";
			subject = "LISTED APP";
			SendEmail(tokens, from, to, subject, path, text);
			deleteFile(path);
			closesocket(sock);
		}
		else if (command.find("start app ") == 0)
		{
			string fileName = "startApp.bmp";
			path = PATH + fileName;
			receiveFile(sock, path.c_str(), hEdit);
			text = "Sended.";
			subject = "START APP";
			SendEmail(tokens, from, to, subject, path, text);
			deleteFile(path);
			closesocket(sock);
		}
		else if (command.find("stop app ") == 0)
		{
			string fileName = "response.txt";
			path = PATH + fileName;
			receiveFile(sock, path.c_str(), hEdit);
			text = "Sended.";
			subject = "STOP APP";
			SendEmail(tokens, from, to, subject, path, text);
			deleteFile(path);
			closesocket(sock);
		}
		else if (command == "list services")
		{
			string fileName = "list_services.txt";
			path = PATH + fileName;
			receiveFile(sock, path.c_str(), hEdit);
			text = "Sended.";
			subject = "LISTED SERVICES";
			SendEmail(tokens, from, to, subject, path, text);
			deleteFile(path);
			closesocket(sock);
		}
		else if (command.find("start service ") == 0)
		{
			string fileName = "response.txt";
			path = PATH + fileName;
			receiveFile(sock, path.c_str(), hEdit);
			text = "Sended.";
			subject = "START SERVICE";
			SendEmail(tokens, from, to, subject, path, text);
			deleteFile(path);
			closesocket(sock);
		}
		else if (command.find("stop service ") == 0)
		{
			string fileName = "response.txt";
			path = PATH + fileName;
			receiveFile(sock, path.c_str(), hEdit);
			text = "Sended.";
			subject = "STOP SERVICE";
			SendEmail(tokens, from, to, subject, path, text);
			deleteFile(path);
			closesocket(sock);
		}
		else if (command == "list process")
		{
			string fileName = "list_process.txt";
			path = PATH + fileName;
			receiveFile(sock, path.c_str(), hEdit);
			text = "Sended.";
			subject = "LISTED PROCESS";
			SendEmail(tokens, from, to, subject, path, text);
			deleteFile(path);
			closesocket(sock);
		}
		else if (command.find("start process ") == 0)
		{
			string fileName = "response.txt";
			path = PATH + fileName;
			receiveFile(sock, path.c_str(), hEdit);
			text = "Sended.";
			subject = "START PROCESS";
			SendEmail(tokens, from, to, subject, path, text);
			deleteFile(path);
			closesocket(sock);
		}
		else if (command.find("stop process ") == 0)
		{
			string fileName = "response.txt";
			path = PATH + fileName;
			receiveFile(sock, path.c_str(), hEdit);
			text = "Sended.";
			subject = "STOP PROCESS";
			SendEmail(tokens, from, to, subject, path, text);
			deleteFile(path);
			closesocket(sock);
		}
		else if (command == "screen shot")
		{
			string fileName = "screen_shot.bmp";
			path = PATH + fileName;
			receiveFile(sock, path.c_str(), hEdit);
			text = "Sended.";
			subject = "SCREEN SHOT";
			SendEmail(tokens, from, to, subject, path, text);
			deleteFile(path);
			closesocket(sock);
		}
		else if (command == "shut down")
		{
			string fileName = "response.txt";
			path = PATH + fileName;
			ofstream res(path);
			res << "Done.\n";
			res.close();
			text = "Sended.";
			subject = "SHUT DOWN";
			SendEmail(tokens, from, to, subject, path, text);
			deleteFile(path);
			closesocket(sock);
		}
		else if (command == "restart")
		{
			string fileName = "response.txt";
			path = PATH + fileName;
			ofstream res(path);
			res << "Done.\n";
			res.close();
			text = "Sended.";
			subject = "RESTART";
			SendEmail(tokens, from, to, subject, path, text);
			deleteFile(path);
			closesocket(sock);
		}
		else if (command == "log out")
		{
			string fileName = "response.txt";
			path = PATH + fileName;
			ofstream res(path);
			res << "Done.\n";
			res.close();
			text = "Sended.";
			subject = "LOG OUT";
			SendEmail(tokens, from, to, subject, path, text);
			deleteFile(path);
			closesocket(sock);
		}
		else if (command.find("start webcam") == 0)
		{
			string fileName = "Webcam.mp4";
			path = PATH + fileName;
			receiveFile(sock, path.c_str(), hEdit);
			text = "done";
			subject = "WEBCAM";
			SendEmail(tokens, from, to, subject, path, text);
			deleteFile(path);
			closesocket(sock);
		}
		else if (command.find("delete file ") == 0)
		{
			string fileName = "response.txt";
			path = PATH + fileName;
			receiveFile(sock, path.c_str(), hEdit);
			text = "Sended.";
			subject = "DELETE FILE";
			SendEmail(tokens, from, to, subject, path, text);
			deleteFile(path);
			closesocket(sock);
		}
		else
		{
			SendMessageA(hEdit, EM_SETSEL, -1, -1);
			SendMessageA(hEdit, EM_REPLACESEL, 0, (LPARAM)"Unknown command\n");
			closesocket(sock);
		}
	}
}

void ResumeReadMail(SOCKET sock, Tokens tokens) {
	stopReadingMail = false; // Đặt lại trạng thái để tiếp tục đọc mail

	// Cấp phát bộ nhớ động cho Tokens
	Tokens* tokensPtr = (Tokens*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(Tokens));
	if (!tokensPtr) {
		MessageBox(NULL, L"Memory allocation failed for Tokens", L"Error", MB_OK);
		return;
	}

	// Sao chép dữ liệu từ `tokens` sang `tokensPtr`
	*tokensPtr = tokens;

	// Tạo thread để xử lý tiếp tục đọc/gửi mail
	HANDLE hResumeThread = CreateThread(NULL, 0, [](LPVOID param) -> DWORD {
		auto args = (std::pair<SOCKET, Tokens*>*)param;
		SOCKET localSock = args->first;
		Tokens* localTokens = args->second;

		// Vòng lặp gửi lệnh
		while (!stopReadingMail) {
			sendCommand(localSock, *localTokens);
			Sleep(1000); // Thêm khoảng chờ để không quá tải
		}

		// Giải phóng bộ nhớ sau khi hoàn thành
		HeapFree(GetProcessHeap(), 0, localTokens);
		delete args;
		return 0;
		}, new std::pair<SOCKET, Tokens*>{ sock, tokensPtr }, 0, NULL);

	if (!hResumeThread) {
		MessageBox(NULL, L"Failed to create ResumeReadMail thread", L"Error", MB_OK);
		HeapFree(GetProcessHeap(), 0, tokensPtr);
		return;
	}

	CloseHandle(hResumeThread); // Đóng handle để tránh rò rỉ tài nguyên
}

DWORD WINAPI ReadingMailThread(LPVOID param) {
	Tokens* tokens = (Tokens*)param;
	string IP = " ";

	while (!stopReadingMail)
	{
		// Bước 1: Đọc mail để lấy IP và lệnh
		if (Mail(*tokens, IP))
		{
			SendMessageA(hEdit, EM_REPLACESEL, 0, (LPARAM)"Get mail successful.\r\n");
		}
		else
			continue;

		// Nếu IP không hợp lệ (trống sau kiểm tra trong Mail), bỏ qua
		if (IP.empty())
		{
			continue;
		}

		// Bước 2: Kết nối tới server qua Socket
		if (Socket(IP)) {
			// Bước 3: Tạo ClientThread nếu Socket thành công
			HANDLE hThread = CreateThread(NULL, 0, ClientThread, (LPVOID)tokens, 0, NULL);
			if (!hThread) {
				MessageBox(NULL, L"Failed to create thread", L"Error", MB_OK);
				break;
			}
			CloseHandle(hThread);
		}
		else {
			MessageBox(NULL, L"Failed to connect to server. Retrying...", L"Error", MB_OK);
			Sleep(5000); // Chờ trước khi thử lại
		}
	}

	// Giải phóng tài nguyên khi vòng lặp kết thúc
	HeapFree(GetProcessHeap(), 0, tokens);
	return 0;
}

DWORD WINAPI ClientThread(LPVOID param) {
	if (!param) {
		MessageBox(NULL, L"Invalid parameter in ClientThread", L"Error", MB_OK);
		return 1; // Kết thúc thread với mã lỗi
	}

	Tokens* tokens = (Tokens*)param;

	if (clientSocket == INVALID_SOCKET) {
		MessageBox(NULL, L"Socket is not connected", L"Error", MB_OK);
		return 1;
	}

	//while (!stopReadingMail)
	sendCommand(clientSocket, *tokens);
	closesocket(clientSocket);
	//HeapFree(GetProcessHeap(), 0, tokens); // Giải phóng bộ nhớ
	return 0;
}

LRESULT CALLBACK Start(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	static HWND hDescriptionText;
	switch (uMsg) {
	case WM_CREATE:
	{
		LPCREATESTRUCT createStruct = (LPCREATESTRUCT)lParam;
		WindowData* pWindowData = (WindowData*)createStruct->lpCreateParams;

		HWND hwndMain = pWindowData->hwndMain;
		HMENU hMenu = pWindowData->hMenu;

		if (!hwndMain) {
			MessageBox(hwnd, L"Failed to retrieve hwndMain", L"Error", MB_OK | MB_ICONERROR);
		}
		else {
			// Lưu hwndMain vào dữ liệu của cửa sổ
			SetWindowLongPtr(hwnd, GWLP_USERDATA, (LONG_PTR)hwndMain);
		}
		HFONT hFontTittle = Font(L"Franklin Gothic Heavy", 40, FW_BOLD);
		// Tạo các Static controls
		hDescriptionText = CreateWindowEx(
			0, L"STATIC", L"Control PC Via Email",
			WS_CHILD | WS_VISIBLE | SS_CENTER,
			120, 10, 600, 80,
			hwnd, NULL, GetModuleHandle(NULL), NULL
		);
		SendMessage(hDescriptionText, WM_SETFONT, (WPARAM)hFontTittle, TRUE);
		// Tạo khung Edit
		hEdit = CreateWindowEx(
			0, L"EDIT", NULL,
			WS_CHILD | WS_VISIBLE | WS_BORDER | ES_MULTILINE | ES_AUTOVSCROLL,
			10, 50, 800, 500,
			hwnd, (HMENU)ID_EDIT, GetModuleHandle(NULL), NULL
		);
		// Đặt màu nền cho Edit control
		SetClassLongPtr(hEdit, GCLP_HBRBACKGROUND, (LONG_PTR)CreateSolidBrush(RGB(203, 253, 228))); // Màu nền: #A0E4A0

		// Tạo nút "Back"
		HWND hButtonBack = Button(hwnd, L"Back", 10, 10, 50, 30, ID_BUTTON_BACK);

		RECT rect;
		GetClientRect(hwnd, &rect);

		int buttonWidth = 100;
		int buttonHeight = 30;
		int gap = 20; 
		int centerX = (rect.right - rect.left) / 2;
		int yPos = rect.bottom - buttonHeight - 20; 

		HWND hButtonStop = Button(hwnd, L"Stop", centerX - buttonWidth - gap / 2, yPos, buttonWidth, buttonHeight, ID_BUTTON_STOP);
		HWND hButtonContinue = Button(hwnd, L"Continue", centerX + gap / 2, yPos, buttonWidth, buttonHeight, ID_BUTTON_CONTINUE);
		break;
	}

	case WM_GETMINMAXINFO: 
	{
		MINMAXINFO* mmi = (MINMAXINFO*)lParam;
		mmi->ptMinTrackSize.x = 840; // Chiều rộng tối thiểu
		mmi->ptMinTrackSize.y = 660; // Chiều cao tối thiểu
		mmi->ptMaxTrackSize.x = 840; // Chiều rộng tối đa
		mmi->ptMaxTrackSize.y = 660; // Chiều cao tối đa
		return 0;
	}

	case WM_PAINT: 
	{
		HDC hdc;
		PAINTSTRUCT ps;
		hdc = BeginPaint(hwnd, &ps);

		// Tạo brush màu nền cho cửa sổ chính
		HBRUSH hBrush = CreateSolidBrush(RGB(203, 253, 228));  // Màu nền của cửa sổ chính
		FillRect(hdc, &ps.rcPaint, hBrush);  // Đổ màu nền cho cửa sổ chính

		// Dọn dẹp brush
		DeleteObject(hBrush);

		EndPaint(hwnd, &ps);
		return 0;
	}

	case WM_CTLCOLOREDIT: {
		if ((HWND)lParam == hEdit) {
			HDC hdcEdit = (HDC)wParam;
			// Đảm bảo rằng màu nền của Edit control vẫn giữ đúng
			SetBkColor(hdcEdit, RGB(203, 253, 228));  // Màu nền #A0E4A0 cho Edit
			SetTextColor(hdcEdit, RGB(0, 0, 0));  // Màu chữ đen
			return (LRESULT)(CreateSolidBrush(RGB(203, 253, 228)));  // Trả về brush cho Edit
		}
		break;
	}

	case WM_CTLCOLORSTATIC: {
		HDC hdcStatic = (HDC)wParam;
		// Kiểm tra nếu là Static control "Welcome" hoặc "Control PC Via Email"
		if ((HWND)lParam == hDescriptionText) {
			// Tạo brush với màu nền giống màu khung Edit
			HBRUSH hBrush = CreateSolidBrush(RGB(203, 253, 228));  // Màu nền #A0E4A0
			SetBkColor(hdcStatic, RGB(203, 253, 228));  // Đặt màu nền cho Static control
			SetTextColor(hdcStatic, RGB(0, 0, 0));  // Đặt màu chữ là đen
			return (LRESULT)hBrush;  // Trả về brush để vẽ nền
		}
		break;
	}

	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case ID_BUTTON_BACK:
		{
			stopReadingMail = 1;
			// Lấy hwndMain từ dữ liệu cửa sổ

			HWND hwndMain = (HWND)GetWindowLongPtr(hwnd, GWLP_USERDATA);

			if (hwndMain) {
				ShowWindow(hwndMain, SW_SHOW);  // Hiển thị màn hình chính
				DestroyWindow(hwnd);           // Đóng màn hình 2
			}
			else {
				MessageBox(hwnd, L"hwndMain not found!", L"Error", MB_OK | MB_ICONERROR);
			}
			break;
		}
		case ID_BUTTON_STOP:
		{
			stopReadingMail = true; // Dừng đọc mail
			SendMessage(hEdit, EM_REPLACESEL, 0, (LPARAM)L"Reading mail stopped.\r\n");
			closesocket(clientSocket);
			break;
		}

		case ID_BUTTON_CONTINUE:
		{
			if (!stopReadingMail)
			{
				SendMessage(hEdit, EM_REPLACESEL, 0, (LPARAM)L"Already reading mail.\r\n");
				break;
			}

			stopReadingMail = false; // Cho phép tiếp tục đọc mail

			// Kiểm tra xem tokens.txt có tồn tại hay không
			if (!CheckTokensExist("tokens.txt"))
			{
				MessageBox(hwnd, L"Please Login", L"Error", MB_OK);
				break;
			}

			// Cấp phát bộ nhớ cho tokens
			Tokens* tokens = (Tokens*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(Tokens));
			if (!tokens)
			{
				SendMessage(hEdit, EM_REPLACESEL, 0, (LPARAM)L"Failed to allocate memory for tokens.\r\n");
				break;
			}

			// Khởi tạo tokens từ file
			*tokens = Start();

			// Tạo luồng ReadingMailThread để tiếp tục đọc mail
			HANDLE hThread = CreateThread(NULL, 0, ReadingMailThread, (LPVOID)tokens, 0, NULL);
			if (!hThread)
			{
				MessageBox(NULL, L"Failed to create thread", L"Error", MB_OK);
				HeapFree(GetProcessHeap(), 0, tokens); // Giải phóng bộ nhớ
				break;
			}

			CloseHandle(hThread); // Đóng handle của luồng
			SendMessage(hEdit, EM_REPLACESEL, 0, (LPARAM)L"Continue reading mail...\r\n");
			break;
		}

		}
		break;

	case WM_DESTROY:
		break;

	default:
		return DefWindowProc(hwnd, uMsg, wParam, lParam);
	}
	return 0;
}

LRESULT CALLBACK About(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	static HWND hDescriptionText, hAboutText;
	static HFONT hFontText, hFontTittle;
	switch (uMsg) {
	case WM_CREATE:
	{
		LPCREATESTRUCT createStruct = (LPCREATESTRUCT)lParam;
		WindowData* pWindowData = (WindowData*)createStruct->lpCreateParams;

		HWND hwndMain = pWindowData->hwndMain;
		HMENU hMenu = pWindowData->hMenu;

		if (!hwndMain) {
			MessageBox(hwnd, L"Failed to retrieve hwndMain", L"Error", MB_OK | MB_ICONERROR);
		}
		else {
			// Lưu hwndMain vào dữ liệu của cửa sổ
			SetWindowLongPtr(hwnd, GWLP_USERDATA, (LONG_PTR)hwndMain);
		}
		hFontTittle = Font(L"Impact", 40, FW_BOLD);
		// Tạo các Static controls
		hDescriptionText = CreateWindowEx(
			0, L"STATIC", L"About",
			WS_CHILD | WS_VISIBLE | SS_CENTER,
			120, 160, 600, 80,
			hwnd, NULL, GetModuleHandle(NULL), NULL
		);
		SendMessage(hDescriptionText, WM_SETFONT, (WPARAM)hFontTittle, TRUE);

		RECT rect;
		GetClientRect(hwnd, &rect);

		// Kích thước cửa sổ
		int width = rect.right - rect.left;
		int height = rect.bottom - rect.top;

		// Kích thước của STATIC control
		int controlWidth = 700;
		int controlHeight = 200;

		// Tính toán vị trí để canh giữa
		int posX = (width - controlWidth) / 2;
		int posY = (height - controlHeight) / 2 + 30;

		hFontText = Font(L"Curier New", 16, FW_BOLD);
		hAboutText = CreateWindowEx(
			0, L"STATIC",
			L"Remote PC project | Group 10 | 23TNT1 | HCMUS\n"
			L"\n"
			L"GVHD: DO HOANG CUONG\n"
			L"\n"
			L"====================== Members =====================\n"
			L"\n"
			L"Phan Huynh Chau Thinh | 23122019\n"
			L"Nguyen Trong Hoa      | 23122029",
			WS_CHILD | WS_VISIBLE | SS_CENTER | SS_EDITCONTROL,
			posX, posY, controlWidth, controlHeight,
			hwnd, NULL, GetModuleHandle(NULL), NULL
		);
		SendMessage(hAboutText, WM_SETFONT, (WPARAM)hFontText, TRUE);
	
		// Tạo nút "Quay Lại"
		HWND hButtonBack = Button(hwnd, L"Back", 10, 10, 50, 30, ID_BUTTON_BACK);

		break;
	}

	case WM_GETMINMAXINFO:
	{
		MINMAXINFO* mmi = (MINMAXINFO*)lParam;
		mmi->ptMinTrackSize.x = 840; // Chiều rộng tối thiểu
		mmi->ptMinTrackSize.y = 660; // Chiều cao tối thiểu
		mmi->ptMaxTrackSize.x = 840; // Chiều rộng tối đa
		mmi->ptMaxTrackSize.y = 660; // Chiều cao tối đa
		return 0;
	}

	case WM_PAINT:
	{
		HDC hdc;
		PAINTSTRUCT ps;
		hdc = BeginPaint(hwnd, &ps);

		// Tạo brush màu nền cho cửa sổ chính
		HBRUSH hBrush = CreateSolidBrush(RGB(203, 253, 228));  // Màu nền của cửa sổ chính
		FillRect(hdc, &ps.rcPaint, hBrush);  // Đổ màu nền cho cửa sổ chính

		DeleteObject(hBrush);

		EndPaint(hwnd, &ps);
		return 0;
	}

	case WM_CTLCOLORSTATIC: {
		HDC hdcStatic = (HDC)wParam;
		if ((HWND)lParam == hAboutText || (HWND)lParam == hDescriptionText) {
			// Tạo brush với màu nền giống màu khung Edit
			HBRUSH hBrush = CreateSolidBrush(RGB(203, 253, 228));  
			SetBkColor(hdcStatic, RGB(203, 253, 228));  // Đặt màu nền cho Static control
			SetTextColor(hdcStatic, RGB(0, 0, 0));  // Đặt màu chữ là đen
			return (LRESULT)hBrush;  // Trả về brush để vẽ nền
		}
		break;
	}

	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case ID_BUTTON_BACK:
		{
			// Lấy hwndMain từ dữ liệu cửa sổ
			HWND hwndMain = (HWND)GetWindowLongPtr(hwnd, GWLP_USERDATA);

			if (hwndMain) {
				ShowWindow(hwndMain, SW_SHOW);  // Hiển thị màn hình chính
				DestroyWindow(hwnd);           
			}
			else {
				MessageBox(hwnd, L"hwndMain not found!", L"Error", MB_OK | MB_ICONERROR);
			}
			break;
		}
		}
		break;

	case WM_DESTROY:
		break;

	default:
		return DefWindowProc(hwnd, uMsg, wParam, lParam);
	}
	return 0;
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	static HWND hConfigButton, hLoginButton, hStartButton, hWelcomeText, hDescriptionText, hEdit;
	switch (uMsg) {
	case WM_CREATE: 
	{
		HFONT hFontText = Font(L"Lucida Handwriting", 16, FW_NORMAL);

		HFONT hFontTittle = Font(L"Franklin Gothic Heavy", 50, FW_BOLD);
		// Tạo các Static controls
		hWelcomeText = CreateWindowEx(
			0, L"STATIC", L"Welcome",
			WS_CHILD | WS_VISIBLE | SS_CENTER,
			290, 100, 300, 40, // X, Y, Width, Height
			hwnd, NULL, GetModuleHandle(NULL), NULL
		);

		SendMessage(hWelcomeText, WM_SETFONT, (WPARAM)hFontText, TRUE);

		hDescriptionText = CreateWindowEx(
			0, L"STATIC", L"Control PC Via Email",
			WS_CHILD | WS_VISIBLE | SS_CENTER,
			120, 160, 600, 80,
			hwnd, NULL, GetModuleHandle(NULL), NULL
		);

		SendMessage(hDescriptionText, WM_SETFONT, (WPARAM)hFontTittle, TRUE);

		// Tạo các nút Login và Start
		hLoginButton = Button(hwnd, L"Login", 340, 240, 100, 40, ID_BUTTON_LOGIN); 

		hStartButton = Button(hwnd, L"Start", 460, 240, 100, 40, ID_BUTTON_START);

		break;
	}

	case WM_GETMINMAXINFO: 
	{
		MINMAXINFO* mmi = (MINMAXINFO*)lParam;
		mmi->ptMinTrackSize.x = 840; // Chiều rộng tối thiểu
		mmi->ptMinTrackSize.y = 660; // Chiều cao tối thiểu
		mmi->ptMaxTrackSize.x = 840; // Chiều rộng tối đa
		mmi->ptMaxTrackSize.y = 660; // Chiều cao tối đa
		return 0;
	}

	case WM_PAINT: {
		HDC hdc;
		PAINTSTRUCT ps;
		hdc = BeginPaint(hwnd, &ps);

		// Tạo brush màu nền cho cửa sổ chính
		HBRUSH hBrush = CreateSolidBrush(RGB(203, 253, 228));  // Màu nền của cửa sổ chính
		FillRect(hdc, &ps.rcPaint, hBrush);  // Đổ màu nền cho cửa sổ chính

		// Dọn dẹp brush
		DeleteObject(hBrush);

		EndPaint(hwnd, &ps);
		return 0;
	}

	case WM_CTLCOLORSTATIC: {
		HDC hdcStatic = (HDC)wParam;
		// Kiểm tra nếu là Static control "Welcome" hoặc "Control PC Via Email"
		if ((HWND)lParam == hWelcomeText || (HWND)lParam == hDescriptionText) {
			// Tạo brush với màu nền giống màu khung Edit
			HBRUSH hBrush = CreateSolidBrush(RGB(203, 253, 228));  
			SetBkColor(hdcStatic, RGB(203, 253, 228));  // Đặt màu nền cho Static control
			SetTextColor(hdcStatic, RGB(0, 0, 0));  // Đặt màu chữ là đen
			return (LRESULT)hBrush;  // Trả về brush để vẽ nền
		}
		break;
	}

	case WM_COMMAND: 
	{
		// Kiểm tra nút bấm
		switch (LOWORD(wParam)) 
		{
		case ID_BUTTON_LOGIN: 
		{
			Tokens* tokens = (Tokens*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(Tokens));
			if (tokens) 
			{
				*tokens = Login();

				/*HANDLE hThread = CreateThread(NULL, 0, ClientThread, (LPVOID)tokens, 0, NULL);
				if (hThread) 
				{
					CloseHandle(hThread);  // Đóng handle thread, thread vẫn chạy
				}
				else 
				{
					HeapFree(GetProcessHeap(), 0, tokens);  // Giải phóng nếu không tạo được thread
				}*/

			}
			break;
		}
		case ID_BUTTON_START: {
			stopReadingMail = false;

			Tokens* tokens = (Tokens*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(Tokens));
			if (!tokens) {
				MessageBox(hwnd, L"Memory allocation failed for Tokens", L"Error", MB_OK);
				return 0;
			}

			if (!CheckTokensExist("tokens.txt")) {
				MessageBox(hwnd, L"Please Login", L"Error", MB_OK);
				HeapFree(GetProcessHeap(), 0, tokens);
				return 0;
			}

			ShowWindow(hwnd, SW_HIDE);
			HWND hwndScreen2 = Screen(
				(HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE),
				L"Start",
				L"Start",
				Start,
				840,
				660,
				NULL,
				hwnd
			);
			if (!hwndScreen2) {
				MessageBox(hwnd, L"Failed to create new window", L"Error", MB_OK);
				HeapFree(GetProcessHeap(), 0, tokens);
				return 0;
			}

			*tokens = Start();

			HANDLE hReadingThread = CreateThread(NULL, 0, ReadingMailThread, (LPVOID)tokens, 0, NULL);
			if (!hReadingThread) {
				MessageBox(hwnd, L"Failed to create thread for reading mail", L"Error", MB_OK);
				HeapFree(GetProcessHeap(), 0, tokens);
				return 0;
			}
			CloseHandle(hReadingThread);
			break;
		}

		case ID_FILE_ABOUT:
		{
			ShowWindow(hwnd, SW_HIDE);

			HWND hwndAbout = Screen(
				(HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE),  // hInstance
				L"About",                                         // className
				L"About screen",                                        // windowTitle
				About,                                        // windowProc
				840,                                                // width
				660,                                                // height
				NULL,                                               // hwndParent
				hwnd                                                // extraData (hwndMain)
			);
			break;
		}
		case ID_FILE_EXIT:
		{
			PostMessage(hwnd, WM_CLOSE, 0, 0);
			break;
		}

		}
		break;
	}

	case WM_CLOSE:
		// Khi đóng cửa sổ, gửi thông điệp yêu cầu đóng cả ứng dụng
		PostQuitMessage(0);
		return 0;
		// Các thông điệp khác...

	case WM_DESTROY: {
		PostQuitMessage(0);
		break;
	}

	default:
		return DefWindowProc(hwnd, uMsg, wParam, lParam);
	}
	return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	if (!RegisterWindowClass(hInstance, L"ClientApp", WindowProc))
	{
		MessageBox(NULL, L"Failed to register window class", L"Error", MB_OK);
		return 0;
	}

	HMENU hMenu = Menu();
	SetMenu(hwnd, hMenu);

	// Create main window
	hwnd = Screen(
		hInstance,                  // Instance của ứng dụng
		L"ClientApp",               // Tên lớp cửa sổ
		L"Control PC Via Email",    // Tiêu đề của cửa sổ
		DefWindowProc,              // Hàm xử lý sự kiện (sử dụng hàm mặc định)
		840,                        // Chiều rộng
		660,                        // Chiều cao
		hMenu
	);

	// Lớp cửa sổ cho màn hình thứ hai
	hInstance = GetModuleHandle(NULL); // Lấy instance của ứng dụng

	// Đăng ký lớp cho Screen2
	if (!RegisterWindowClass(hInstance, L"Start", Start)) {
		MessageBox(NULL, L"Failed to register screen 2 class", L"Error", MB_OK);
		return 0;
	}
	//Đăng ký lớp cho About
	if (!RegisterWindowClass(hInstance, L"About", About)) {
		MessageBox(NULL, L"Failed to register About class", L"Error", MB_OK);
		return 0;
	}

	// Run the message loop
	MSG msg = {};
	while (GetMessage(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return (int)msg.wParam;
}