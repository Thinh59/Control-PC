﻿#include "app.h"

HWND hwnd = nullptr;  
HWND hEdit = nullptr; 
SOCKET clientSocket = INVALID_SOCKET;  

HMENU Menu() 
{
	HMENU hMenu = CreateMenu();

	HMENU hFileMenu = CreatePopupMenu();
	AppendMenu(hFileMenu, MF_STRING, ID_FILE_ABOUT, L"About Us");
	AppendMenu(hFileMenu, MF_STRING, ID_FILE_EXIT, L"Exit");

	AppendMenu(hMenu, MF_POPUP, (UINT_PTR)hFileMenu, L"File");

	return hMenu;
}

HFONT Font(const wstring& fontName, int fontSize, int fontWeight, bool italic, bool underline, bool strikeout)
{
	HFONT hFont = CreateFont(
		fontSize,            
		0,                   
		0,                   
		0,                  
		fontWeight,          
		italic,              
		underline,           
		strikeout,           
		ANSI_CHARSET,        
		OUT_DEFAULT_PRECIS,  
		CLIP_DEFAULT_PRECIS, 
		DEFAULT_QUALITY,     
		DEFAULT_PITCH | FF_SWISS, 
		fontName.c_str()     
	);

	if (!hFont) 
	{
		MessageBox(NULL, L"Failed to create font!", L"Error", MB_OK | MB_ICONERROR);
	}

	return hFont;
}

HWND Button(HWND hwndParent, LPCWSTR buttonText, int x, int y, int width, int height, UINT buttonID) 
{
	// Tạo font chữ Courier New
	HFONT hFont = Font(L"Courier New", 16, FW_BOLD);

	// Tạo nút và gán ID cho nó
	HWND hwndButton = CreateWindow(
		L"BUTTON", buttonText, // Tên lớp và văn bản hiển thị
		WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, // Các thuộc tính của nút
		x, y, width, height, // Vị trí và kích thước
		hwndParent, // Cửa sổ cha
		(HMENU)buttonID, // Truyền ID nút qua hMenu
		(HINSTANCE)GetWindowLongPtr(hwndParent, GWLP_HINSTANCE), // Instance của ứng dụng
		NULL // Không có dữ liệu bổ sung
	);

	// Áp dụng font vào nút
	SendMessage(hwndButton, WM_SETFONT, (WPARAM)hFont, TRUE);

	return hwndButton;
}

ATOM RegisterWindowClass(HINSTANCE hInstance, LPCWSTR className, WNDPROC windowProc, HBRUSH background, HCURSOR cursor)
{
	WNDCLASS wc = {};
	wc.lpfnWndProc = windowProc;          
	wc.hInstance = hInstance;            
	wc.lpszClassName = className;         
	wc.hbrBackground = background;       
	wc.hCursor = cursor;                  

	ATOM result = RegisterClass(&wc);     
	if (!result) 
	{
		MessageBox(NULL, L"Failed to register window class!", L"Error", MB_OK | MB_ICONERROR);
	}
	return result;
}

HWND Screen(HINSTANCE hInstance, LPCWSTR className, LPCWSTR windowTitle, WNDPROC windowProc, int width, int height, HMENU hMenu, HWND hwndParent, LPVOID extraData)
{
	WindowData* pWindowData = new WindowData();
	pWindowData->hwndMain = hwndParent;  // Gán hwndParent cho hwndMain trong WindowData
	pWindowData->hMenu = hMenu;
	// Tạo cửa sổ
	HWND hwnd = CreateWindowEx(
		0,                     // Extended style
		className,             // Tên lớp cửa sổ
		windowTitle,           // Tiêu đề
		WS_OVERLAPPEDWINDOW,   // Kiểu cửa sổ
		CW_USEDEFAULT, CW_USEDEFAULT, width, height,
		hwndParent,            // Cửa sổ cha (nếu có)
		hMenu,                  // Không có menu
		hInstance,             // Instance của ứng dụng
		(LPVOID)pWindowData
	);

	if (!hwnd) 
	{
		MessageBox(NULL, L"Failed to create window!", L"Error", MB_OK | MB_ICONERROR);
		return NULL;
	}

	ShowWindow(hwnd, SW_SHOW);
	UpdateWindow(hwnd);
	return hwnd;
}