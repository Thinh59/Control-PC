#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <iostream>
#include <curl.h>
#include <string.h>
#include <windows.h>
#include <nlohmann/json.hpp>
#include <WinSock2.h>
#include <sstream>
#include <iomanip>
#include <map>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <string>

using json = nlohmann::json;

#pragma comment(lib, "ws2_32.lib")
#define PORT 8080
#define BUFFER_SIZE 65536
#define MAX_DATH 260
#define PATH "C:\\"

using namespace std;

struct Credentials
{
	string client_id;
	string client_secret;
};

struct Tokens
{
	string access_token;
	string refresh_token;
};

string url_decode(const string& str);
string extractAuthCode(const string& url);
string SocketListenOnPort(int port);
string SocketListenOnPort(int port);
string UrlEncode(const string& str);
int openAuthorizationURL(const char* url);
string GetAuthCode(Credentials cred, string scope, string redirect_uri, int port);
size_t WriteCallBack(void* contents, size_t size, size_t nmemb, string* output);
void ExtractAccessAndRefresh(string rawToken, string& accessToken, string& refreshToken);
string ExchangeRawAccessRefreshToken(Credentials cred, string scope, string redirect_uri, string authCode);
Tokens GetTokens(Credentials cred, string scope, string redirect_uri, int port);
json GetMailList(Tokens tokens, int maxMsgs = 1, string query = "NA");
json GetMailFromID(Tokens tokens, string mailID);
void WriteFile(string path, string content);
Tokens ReadTokens(string path);
string GetMailSubject(Tokens tokens, string mailID);
string GetMailSnippet(Tokens tokens, string mailID);
string GetMailReceivedTime(Tokens tokens, string mailID);
string ReadEmail(Tokens tokens);
string encode_base64(const vector<unsigned char>& buffer);
vector<unsigned char> read_file(const string& filename);
void ExtractFileInfo(string pathToFileContent, string& fileName, string& fileType);
string ByteFile(string path);
string MIMEStructure(string from, string to, string subject, string pathToFileContent, string textContent);
void SendEmail(Tokens tokens, string from, string to, string subject, string pathToFileContent, string textContent);
string GetMailSenderName(Tokens tokens, string mailID);
string FileName(const string& path);
void receiveFile(SOCKET serverSocket, const char* fileName, HWND hEdit);
bool deleteFile(const string& fileName);
Tokens Login();
Tokens Start();
bool CheckTokensExist(const string& filename);

#endif 