﻿#ifndef APP_H
#define APP_H

#include <windows.h>
#include <string> 

using namespace std;

#define ID_BUTTON_LOGIN 1
#define ID_BUTTON_START 2
#define ID_EDIT 101
#define ID_BUTTON_BACK 3
#define ID_HELP_INSTRUCTION 4
#define ID_FILE_ABOUT 5
#define ID_FILE_EXIT 6
#define ID_BUTTON_STOP 7
#define ID_BUTTON_CONTINUE 8
#define IDD_DIALOG1 9
#define IDC_EDIT_IP 10


typedef struct {
	HWND hwndMain;
	HMENU hMenu;
} WindowData;

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
DWORD WINAPI ClientThread(LPVOID param);

HMENU Menu();
HFONT Font(const wstring& fontName, int fontSize, int fontWeight = FW_NORMAL, bool italic = false, bool underline = false, bool strikeout = false);
HWND Button(HWND hwndParent, LPCWSTR buttonText, int x, int y, int width, int height, UINT buttonID);
ATOM RegisterWindowClass(HINSTANCE hInstance, LPCWSTR className, WNDPROC windowProc, HBRUSH background = (HBRUSH)(COLOR_WINDOW + 1), HCURSOR cursor = LoadCursor(NULL, IDC_ARROW));
HWND Screen(HINSTANCE hInstance, LPCWSTR className, LPCWSTR windowTitle, WNDPROC windowProc, int width, int height, HMENU hMenu, HWND hwndParent = NULL, LPVOID extraData = NULL);

#endif